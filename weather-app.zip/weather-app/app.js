const yargs = require('yargs');
const geocode = require('./geocode/geocode');
const weather = require('./weather/weather');
var http = require("http");

const argv = yargs
  .options({
    a: {
      demand: true,
      alias: 'address',
      describe: 'Address to fetch weather for',
      string: true
    }
})
.help()
.alias('help', 'h')
.argv;

//e357ea49a539dcbe06a167380cc71576

http.createServer(function (request, response) {
  response.writeHead(200, {'Content-Type': 'text/plain'});
  geocode.geocodeAddress(argv.a, (errorMessage, results) => {

  if(errorMessage){
    console.log(errorMessage);
  }else {
   weather.getWeather(results.latitude, results.latitude, (errorMessage, weatherresults) => {
     if(errorMessage){
       console.log(errorMessage);
     }else {
       response.end(`In ${results.address}, Its currently ${weatherresults.temperature} but it feels like ${weatherresults.apparentTemperature}`);
     }
   });

}

  });
}).listen(8081);
